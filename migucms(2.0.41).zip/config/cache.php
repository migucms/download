<?php
return array (
  'type' => 'file',
  'prefix' => 'a6bcf9aa58_',
  'path' => '',
  'expire' => 0,
);