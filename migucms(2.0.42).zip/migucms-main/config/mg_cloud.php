<?php
// 请妥善保管此文件，谨防泄漏
return ['identifier' => '', 'no' => ''];
