<?php
return array (
  0 => '视频管理,/video/vod/data',
  1 => '采集资源中心,/video/collect/union',
);
